const footer: { title: string; href: string }[] = [
  {
    title: "Blog",
    href: "/blogs",
  },
  {
    title: "Newsletter",
    href: "/news",
  },
];

export { footer };
