// libs/lenis.js
"use client";

export * from "lenis/react";
